﻿// using System;
// using System.Collections.Generic;
// using System.Linq;
// using System.Web;
// using Microsoft.AspNetCore.Mvc;

// namespace QLNH.Areas.QuanLy.Controllers
// {
//     public class LoaiMonAnController : Controller
//     {
//         // GET: QuanLy/LoaiMonAn
//         public ActionResult Index()
//         {

//             return View(context.LoaiMonAns.ToList());
//         }
//     }
// }