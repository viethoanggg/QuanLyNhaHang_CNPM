using ApplicationCore.Entitites;
using QuanLyNhaHang.Services;

namespace QuanLyNhaHang.ViewModels
{
    public class BanAnVM
    {
        public PaginatedList<BanAn> BanAns{ get; set; }
    }
}