using ApplicationCore.ModelsContainData.Models;
using ApplicationCore.Services;

namespace QuanLyNhaHang.ViewModels
{
    public class ThucDonVM
    {
        public PaginatedList<ThucDonMD> ThucDonsMD{ get; set; }
        
    }
}