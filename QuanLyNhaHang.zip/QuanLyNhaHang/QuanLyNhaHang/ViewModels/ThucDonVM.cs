using QuanLyNhaHang.Models;
using QuanLyNhaHang.Services;

namespace QuanLyNhaHang.ViewModels
{
    public class ThucDonVM
    {
        public PaginatedList<ThucDonMD> ThucDonsMD{ get; set; }
    }
}