using ApplicationCore.DTOs;
using ApplicationCore.Services;

namespace QuanLyNhaHang.ViewModels
{
    public class LoaiMonAnVM
    {
        public PaginatedList<LoaiMonAnDTO> LoaiMonAns{ get; set; }
    }
}