﻿using System;

namespace ApplicationCore
{
    public class Class1
    {
    }
}
