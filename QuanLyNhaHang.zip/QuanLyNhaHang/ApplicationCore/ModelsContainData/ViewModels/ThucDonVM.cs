using ApplicationCore.ModelsContainData.Models;
using ApplicationCore.Services;

namespace ApplicationCore.ModelsContainData.ViewModels
{
    public class ThucDonVM
    {
        public PaginatedList<ThucDonMD> ThucDonsMD{ get; set; }
        
    }
}