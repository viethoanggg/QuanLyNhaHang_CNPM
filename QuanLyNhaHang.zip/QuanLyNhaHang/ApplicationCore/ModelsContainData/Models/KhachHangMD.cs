namespace ApplicationCore.ModelsContainData.Models
{
    public class KhachHangMD
    {
        public int Id { get; set; }
        public string Ten { get; set; }
        public string SDT { get; set; }
        public string DiaChi{ get; set; }
    }
}