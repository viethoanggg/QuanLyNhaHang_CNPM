namespace ApplicationCore.Interfaces
{
    public interface IAggregateRoot
    {
        
    }
}